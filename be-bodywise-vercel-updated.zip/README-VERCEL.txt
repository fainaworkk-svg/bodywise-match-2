BE BODYWISE PERSONALISED CARE APP
================================

WHAT THIS UPDATE CHANGES
------------------------
- Keeps the existing page structure, Poppins typography, blue/white palette, cards,
  left navigation, progress bar and general dashboard layout.
- Rebrands the in-app navigation and browser titles to Be Bodywise.
- Uses a Be Bodywise wordmark image in the sidebar, with a text fallback if the
  image host is unavailable. The Mosaic Wellness relationship is shown as text.
- Adds seven browse categories: Face Care, Body Care, Hair Care, Sun Protection,
  Nutrition & Gummies, Health & Fitness and Winter Care.
- Adds a searchable and filterable product guide. It shows six products initially
  and lets the visitor search or expand the results, rather than showing one long list.
- Expands the quiz dynamically. It asks skin questions only when skin-related
  categories are selected, hair questions for hair, and dietary preference for
  nutrition/fitness selections.
- Adds usage instructions and result expectations where brand guidance could be
  verified. It does not invent an exact result timeline for other products.
- Adds official customer-care links, phone, email, Instagram and LinkedIn.
- Retains the original eight pages and customer-voice/research section.

PRODUCT CATALOGUE NOTE
---------------------
The local product guide contains 54 curated product entries surfaced in the
current official category pages reviewed for this prototype. It is not a live
product feed and it does not guarantee that every SKU, size, variant or item is
listed. The "Shop all Be Bodywise products" links open the live official store,
which remains the source of truth for availability, prices, variants and the
latest catalogue.

Product-specific timelines are included only where an official product page
provided a usable frequency or period (for example, selected body washes,
urea lotion and hair-growth products). Such timelines are brand-published
expectations, not guaranteed outcomes. Where a fixed period could not be
verified, the guide says so and directs users to the latest product label.
Stop using a product if it causes persistent irritation and seek appropriate
professional advice for health concerns. This prototype is informational, not
medical advice.

FILES
-----
- index.html, quiz.html, matches.html, ingredients.html, compatibility.html,
  routine.html, offers.html, insights.html
- core.js: catalogue, quiz questions, matching and compatibility logic
- app.js: page rendering, interactions, search and customer-care links
- style.css: original styles plus small additive component styles
- vercel.json: clean URL configuration

DEPLOY TO YOUR EXISTING VERCEL PROJECT (GITHUB CONNECTED)
--------------------------------------------------------
1. Download and unzip this folder.
2. In your existing GitHub repository, replace the corresponding project files
   with the files from this folder. Keep index.html at the repository root.
3. Commit and push the changes to the production branch (commonly main).
   Example commands, run in the repository folder:

      git add .
      git commit -m "Enhance Be Bodywise personalisation app"
      git push

4. Vercel automatically creates a deployment when a commit is pushed to the
   connected repository. Check the Deployments tab, then open the live URL.

DEPLOY TO YOUR EXISTING VERCEL PROJECT (CLI)
--------------------------------------------
1. Install Node.js if it is not already installed.
2. Open a terminal in the unzipped project folder (the folder that directly
   contains index.html, core.js, app.js and style.css).
3. Run:

      npm install --global vercel@latest
      vercel login
      vercel link

4. When prompted, select the existing Vercel project for the current site.
5. Deploy the production version:

      vercel --prod

There is no npm build step or package installation required for this static
HTML/CSS/JavaScript project. Do not upload only the ZIP as a file; unzip it and
deploy the folder containing index.html at its top level.

BROWSER STORAGE
---------------
Quiz answers and saved routines are stored in localStorage in the visitor's
browser. There is no backend, sign-in, cross-device sync or central customer
profile in this prototype.
